package com.proj.anaas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnaasApplicationTests {

	@Test
	void contextLoads() {
	}

}
